Derived from the 17ec6 version, dcnum version 2 model file format
(batch normalization folded, CPU wiring options: inductor, openvino, torch.eager)
