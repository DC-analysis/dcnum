This is the `unet-dcnum-test_g1_910c2.dcnm` model file converted to the dcnum v2 file format.
