Compared to the 02dcd model, the a8773 model has
additional "wiring_options" metadata, removed the
"batch_size" metadata, and added dynamic batch sizes.
