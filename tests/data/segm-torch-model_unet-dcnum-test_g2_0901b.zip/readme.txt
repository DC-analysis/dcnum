Derived from the 17ec6 version, dcnum version 2 model file format
